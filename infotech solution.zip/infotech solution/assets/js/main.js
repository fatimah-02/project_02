// Navigation scroll effect
window.addEventListener("scroll", function () {
  const navbar = document.querySelector(".navbar");
  if (window.scrollY > 50) {
    navbar.classList.add("scrolled");
  } else {
    navbar.classList.remove("scrolled");
  }
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault();
    document.querySelector(this.getAttribute("href")).scrollIntoView({
      behavior: "smooth",
    });
  });
});

// GSAP Animations
document.addEventListener("DOMContentLoaded", function () {
  // Animate hero section elements
  gsap.from(".hero-section h1", {
    duration: 1,
    y: 50,
    opacity: 0,
    ease: "power3.out",
  });

  gsap.from(".hero-section p", {
    duration: 1,
    y: 50,
    opacity: 0,
    delay: 0.3,
    ease: "power3.out",
  });

  gsap.from(".hero-section .btn", {
    duration: 1,
    y: 50,
    opacity: 0,
    delay: 0.6,
    ease: "power3.out",
  });

  // Animate service cards on hover
  const serviceCards = document.querySelectorAll(".service-card");
  serviceCards.forEach((card) => {
    card.addEventListener("mouseenter", () => {
      gsap.to(card, {
        duration: 0.3,
        scale: 1.05,
        ease: "power1.out",
      });
    });

    card.addEventListener("mouseleave", () => {
      gsap.to(card, {
        duration: 0.3,
        scale: 1,
        ease: "power1.out",
      });
    });
  });
});

// Dark/Light Mode Toggle
const modeToggle = document.createElement("div");
modeToggle.className = "mode-toggle";
modeToggle.innerHTML = '<i class="fas fa-moon"></i>';
document.body.appendChild(modeToggle);

modeToggle.addEventListener("click", function () {
  document.body.classList.toggle("dark-mode");
  const icon = this.querySelector("i");
  if (document.body.classList.contains("dark-mode")) {
    icon.classList.remove("fa-moon");
    icon.classList.add("fa-sun");
  } else {
    icon.classList.remove("fa-sun");
    icon.classList.add("fa-moon");
  }
});

// Add dark mode styles
const style = document.createElement("style");
style.textContent = `
.dark-mode {
    background-color: #121212;
    color: #f5f5f5;
}

.dark-mode .navbar {
    background-color: #1a1a1a !important;
}

.dark-mode .card {
    background-color: #1e1e1e;
    color: #f5f5f5;
}

.dark-mode .mode-toggle {
    color: #f5f5f5;
}
`;
document.head.appendChild(style);

// WhatsApp Floating Button
const whatsappBtn = document.createElement("a");
whatsappBtn.href = "https://wa.me/15551234567";
whatsappBtn.target = "_blank";
whatsappBtn.className = "whatsapp-btn";
whatsappBtn.innerHTML = '<i class="fab fa-whatsapp"></i>';
document.body.appendChild(whatsappBtn);

// Add styles for WhatsApp button
const whatsappStyle = document.createElement("style");
whatsappStyle.textContent = `
.whatsapp-btn {
    position: fixed;
    bottom: 30px;
    right: 30px;
    width: 60px;
    height: 60px;
    background-color: #25D366;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    z-index: 1000;
    transition: all 0.3s ease;
}

.whatsapp-btn:hover {
    transform: scale(1.1);
    color: white;
}
`;
document.head.appendChild(whatsappStyle);
